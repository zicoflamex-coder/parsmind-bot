import logging
import os
import json
import base64
import datetime
import asyncio
import requests
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
ADMIN_USERNAME = "trippiezico"

MODEL = "meta-llama/llama-3.3-8b-instruct:free"
IMAGE_MODEL = "google/gemini-flash-1.5"

logging.basicConfig(format="%(asctime)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

DATA_FILE = "users_data.json"
REMINDERS_FILE = "reminders.json"

# ─── دیتابیس ───
def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_reminders():
    if os.path.exists(REMINDERS_FILE):
        with open(REMINDERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_reminders(reminders):
    with open(REMINDERS_FILE, "w", encoding="utf-8") as f:
        json.dump(reminders, f, ensure_ascii=False, indent=2)

def get_user(user_id, user):
    data = load_data()
    uid = str(user_id)
    if uid not in data:
        data[uid] = {
            "id": user_id,
            "username": user.username or "",
            "first_name": user.first_name or "",
            "joined": str(datetime.datetime.now()),
            "messages": 0,
            "profile": {},
            "personality": "دوستانه",
            "mode": "normal"
        }
        save_data(data)
    return data[uid]

def save_user_field(user_id, key, value):
    data = load_data()
    uid = str(user_id)
    if uid in data:
        data[uid][key] = value
        save_data(data)

def update_user_profile(user_id, key, value):
    data = load_data()
    uid = str(user_id)
    if uid in data:
        if "profile" not in data[uid]:
            data[uid]["profile"] = {}
        data[uid]["profile"][key] = value
        save_data(data)

def increment_messages(user_id):
    data = load_data()
    uid = str(user_id)
    if uid in data:
        data[uid]["messages"] = data[uid].get("messages", 0) + 1
        save_data(data)

def is_admin(user):
    return (user.username or "").lower() == ADMIN_USERNAME.lower()

user_histories = {}

# ─── OpenRouter ───
def call_openrouter(messages, model=None):
    if model is None:
        model = MODEL
    try:
        response = requests.post(
            url="https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://t.me/ParsMindBot",
                "X-Title": "ParsMind Bot"
            },
            json={"model": model, "messages": messages, "max_tokens": 300},
            timeout=30
        )
        result = response.json()
        if "choices" in result:
            return result["choices"][0]["message"]["content"]
        elif "error" in result:
            logger.error(f"OpenRouter error: {result['error']}")
            return None
    except Exception as e:
        logger.error(f"Exception: {e}")
        return None

def build_system_prompt(user_info):
    personality = user_info.get("personality", "دوستانه")
    mode = user_info.get("mode", "normal")
    profile = user_info.get("profile", {})

    if personality == "رسمی":
        tone = "با لحن کاملاً رسمی و حرفه‌ای صحبت کن. از کلمات محترمانه استفاده کن."
    elif personality == "طنز":
        tone = "با لحن شوخ و بامزه صحبت کن. گاهی جوک یا طنز اضافه کن."
    elif personality == "مختصر":
        tone = "خیلی کوتاه و مختصر جواب بده. بیشتر از ۲-۳ جمله نگو."
    else:
        tone = "با لحن دوستانه و صمیمی صحبت کن."

    system = f"""تو یک دستیار هوشمند فارسی زبان هستی به نام ParsMind.
همیشه به فارسی جواب بده مگر اینکه کاربر به زبان دیگه‌ای بنویسه.
{tone}"""

    if mode == "roleplay":
        role = profile.get("roleplay_role", "یک دستیار هوشمند")
        system += f"\n\nالان در حالت نقش‌آفرینی هستی. نقش تو: {role}\nکاملاً در نقش بمون و از اون خارج نشو."

    if profile:
        system += f"\n\nاطلاعات کاربر: {json.dumps(profile, ensure_ascii=False)}"

    return system

def ask_ai(user_id, user_message, user_info=None):
    if user_id not in user_histories:
        user_histories[user_id] = []
    system = build_system_prompt(user_info) if user_info else "تو یک دستیار هوشمند فارسی زبان هستی."
    user_histories[user_id].append({"role": "user", "content": user_message})
    if len(user_histories[user_id]) > 20:
        user_histories[user_id] = user_histories[user_id][-20:]
    messages = [{"role": "system", "content": system}] + user_histories[user_id]
    reply = call_openrouter(messages)
    if reply:
        user_histories[user_id].append({"role": "assistant", "content": reply})
        return reply
    return "⚠️ متأسفم، یه مشکلی پیش اومد. دوباره امتحان کن."

def analyze_image(image_base64, prompt):
    messages = [{
        "role": "user",
        "content": [
            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}},
            {"type": "text", "text": prompt}
        ]
    }]
    return call_openrouter(messages, model=IMAGE_MODEL)

def generate_image_pollinations(prompt):
    try:
        translate_msg = [{"role": "user", "content": f"Translate this to English for image generation, only output the English text: {prompt}"}]
        english_prompt = call_openrouter(translate_msg) or prompt
        clean_prompt = english_prompt.strip().replace(" ", "%20")[:500]
        image_url = f"https://image.pollinations.ai/prompt/{clean_prompt}?width=512&height=512&nologo=true"
        response = requests.get(image_url, timeout=60)
        if response.status_code == 200:
            return response.content, english_prompt
        return None, None
    except Exception as e:
        logger.error(f"Image generation error: {e}")
        return None, None

def image_to_prompt(image_base64, user_request):
    messages = [{
        "role": "user",
        "content": [
            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}},
            {"type": "text", "text": f"این عکس رو نگاه کن. کاربر میخواد: {user_request}\nیه پرامپت انگلیسی کوتاه برای Stable Diffusion بنویس. فقط پرامپت انگلیسی."}
        ]
    }]
    return call_openrouter(messages, model=IMAGE_MODEL)

# ─── هندلرها ───

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    get_user(user.id, user)
    await update.message.reply_text(
        f"سلام {user.first_name} عزیز! 👋\n\n"
        "من ParsMind هستم 🤖\n\n"
        "📌 دستورات اصلی:\n"
        "/help — راهنمای کامل\n"
        "/profile — پروفایل شما\n"
        "/personality — تنظیم شخصیت\n"
        "/roleplay — حالت نقش‌آفرینی\n"
        "/remind — یادآور\n"
        "/new — مکالمه جدید\n\n"
        "🎨 عکس بساز: عکس [توضیح]\n"
        "🔍 جستجو: جستجو [موضوع]\n"
        "🌐 ترجمه: ترجمه [متن]\n"
        "📝 خلاصه: خلاصه [متن]"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 راهنمای کامل ParsMind\n\n"
        "💬 چت: هر چیزی بپرس\n"
        "🌐 ترجمه: بنویس 'ترجمه [متن]'\n"
        "📝 خلاصه: بنویس 'خلاصه [متن]'\n"
        "🔍 جستجو: بنویس 'جستجو [موضوع]'\n"
        "🎨 ساخت عکس: بنویس 'عکس [توضیح]'\n\n"
        "🖼 تحلیل عکس: عکس بفرست\n"
        "🎵 تشخیص آهنگ: عکس + 'این آهنگ چیه'\n"
        "📊 تحلیل فیش: عکس + 'تحلیل فیش'\n"
        "🎨 ویرایش عکس: عکس + کپشن بفرست\n\n"
        "👤 /profile — پروفایل\n"
        "🧠 /personality — تنظیم لحن\n"
        "🎭 /roleplay — نقش‌آفرینی\n"
        "⏰ /remind — یادآور\n"
        "🔄 /new — مکالمه جدید"
    )

async def new_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_histories[update.effective_user.id] = []
    await update.message.reply_text("✅ مکالمه جدید شروع شد!")

async def profile_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    info = get_user(user.id, user)
    profile = info.get("profile", {})
    text = f"👤 پروفایل شما\n\n"
    text += f"🆔 آیدی: {user.id}\n"
    text += f"👋 اسم: {info.get('first_name', '-')}\n"
    if info.get('username'):
        text += f"📎 یوزرنیم: @{info['username']}\n"
    text += f"📅 عضویت: {info.get('joined', '-')[:10]}\n"
    text += f"💬 پیام‌ها: {info.get('messages', 0)}\n"
    text += f"🧠 شخصیت: {info.get('personality', 'دوستانه')}\n"
    text += f"🎭 حالت: {info.get('mode', 'normal')}\n"
    if profile.get('name'):
        text += f"✏️ اسم: {profile['name']}\n"
    if profile.get('interests'):
        text += f"⭐ علایق: {', '.join(profile['interests'])}\n"
    await update.message.reply_text(text)

async def setname_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("مثال: /setname علی")
        return
    name = " ".join(context.args)
    update_user_profile(update.effective_user.id, "name", name)
    await update.message.reply_text(f"✅ اسمت رو ذخیره کردم: {name}")

async def setinterest_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("مثال: /setinterest فوتبال موسیقی")
        return
    update_user_profile(update.effective_user.id, "interests", context.args)
    await update.message.reply_text(f"✅ علایقت: {', '.join(context.args)}")

async def personality_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            "🧠 تنظیم شخصیت ربات:\n\n"
            "/personality دوستانه — صمیمی و گرم\n"
            "/personality رسمی — حرفه‌ای\n"
            "/personality طنز — شوخ و بامزه\n"
            "/personality مختصر — کوتاه و سریع"
        )
        return
    personality = context.args[0]
    valid = ["دوستانه", "رسمی", "طنز", "مختصر"]
    if personality not in valid:
        await update.message.reply_text(f"گزینه‌های معتبر: {', '.join(valid)}")
        return
    save_user_field(update.effective_user.id, "personality", personality)
    await update.message.reply_text(f"✅ شخصیت ربات به '{personality}' تغییر کرد!")

async def roleplay_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    info = get_user(user.id, user)
    if not context.args:
        mode = info.get("mode", "normal")
        if mode == "roleplay":
            save_user_field(user.id, "mode", "normal")
            await update.message.reply_text("✅ حالت نقش‌آفرینی خاموش شد.")
        else:
            await update.message.reply_text(
                "🎭 حالت نقش‌آفرینی\n\n"
                "مثال:\n"
                "/roleplay یه دکتر متخصص باش\n"
                "/roleplay یه معلم ریاضی باش\n"
                "/roleplay یه دوست صمیمی باش\n\n"
                "برای خاموش کردن: /roleplay"
            )
        return
    role = " ".join(context.args)
    save_user_field(user.id, "mode", "roleplay")
    update_user_profile(user.id, "roleplay_role", role)
    user_histories[user.id] = []
    await update.message.reply_text(f"🎭 حالت نقش‌آفرینی فعال شد!\nنقش: {role}\n\nمکالمه جدید شروع شد.")

async def remind_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "⏰ یادآور\n\n"
            "فرمت: /remind [دقیقه] [پیام]\n\n"
            "مثال:\n"
            "/remind 30 داروت رو بخور\n"
            "/remind 60 جلسه داری"
        )
        return
    try:
        minutes = int(context.args[0])
        message = " ".join(context.args[1:])
        user_id = update.effective_user.id

        reminders = load_reminders()
        remind_time = (datetime.datetime.now() + datetime.timedelta(minutes=minutes)).isoformat()
        reminders.append({
            "user_id": user_id,
            "message": message,
            "time": remind_time,
            "done": False
        })
        save_reminders(reminders)

        await update.message.reply_text(f"✅ یادآور تنظیم شد!\n⏰ بعد از {minutes} دقیقه\n📝 {message}")

        async def send_reminder():
            await asyncio.sleep(minutes * 60)
            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=f"⏰ یادآور!\n\n📝 {message}"
                )
            except Exception as e:
                logger.error(f"Reminder error: {e}")

        asyncio.create_task(send_reminder())

    except ValueError:
        await update.message.reply_text("⚠️ عدد دقیقه رو درست وارد کن. مثال: /remind 30 داروت رو بخور")

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not is_admin(user):
        await update.message.reply_text("⛔ این دستور فقط برای ادمین هست!")
        return
    data = load_data()
    total = len(data)
    total_msgs = sum(u.get("messages", 0) for u in data.values())
    text = f"📊 آمار ربات\n\n👥 کل کاربران: {total}\n💬 کل پیام‌ها: {total_msgs}\n\n"
    text += "─────────────\n"
    for uid, u in list(data.items()):
        name = u.get('first_name', 'ناشناس')
        username = f"@{u['username']}" if u.get('username') else '─'
        msgs = u.get('messages', 0)
        user_id = u.get('id', uid)
        text += f"👤 {name} | {username}\n🆔 {user_id} | 💬 {msgs}\n\n"
    await update.message.reply_text(text)

async def broadcast_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not is_admin(user):
        await update.message.reply_text("⛔ این دستور فقط برای ادمین هست!")
        return
    if not context.args:
        await update.message.reply_text("مثال: /broadcast سلام به همه!")
        return
    message = " ".join(context.args)
    data = load_data()
    success = 0
    fail = 0
    for uid, u in data.items():
        try:
            await context.bot.send_message(
                chat_id=u["id"],
                text=f"📢 پیام از ادمین:\n\n{message}"
            )
            success += 1
            await asyncio.sleep(0.05)
        except Exception:
            fail += 1
    await update.message.reply_text(f"✅ پیام ارسال شد!\n📤 موفق: {success}\n❌ ناموفق: {fail}")

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    get_user(user.id, user)
    increment_messages(user.id)
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")

    photo = update.message.photo[-1]
    file = await context.bot.get_file(photo.file_id)
    file_bytes = await file.download_as_bytearray()
    image_base64 = base64.b64encode(file_bytes).decode("utf-8")
    caption = (update.message.caption or "").strip()

    # تشخیص نوع درخواست
    if any(w in caption for w in ["آهنگ", "موزیک", "موسیقی", "song", "music"]):
        prompt = "این عکس رو نگاه کن. اگه اطلاعاتی از آهنگ یا موسیقی داره (نام آهنگ، خواننده، آلبوم) بگو. اگه از پوستر یا کاور آلبوم هست توضیح بده."
        reply = analyze_image(image_base64, prompt)
        await update.message.reply_text(reply or "⚠️ نتونستم تشخیص بدم.")

    elif any(w in caption for w in ["فیش", "رسید", "قبض", "صورتحساب", "invoice"]):
        prompt = "این فیش یا رسید رو تحلیل کن. مبلغ، تاریخ، موارد خریداری شده و هر اطلاعات مهمی رو به فارسی بگو."
        reply = analyze_image(image_base64, prompt)
        await update.message.reply_text(reply or "⚠️ نتونستم فیش رو تحلیل کنم.")

    elif caption and any(w in caption for w in ["کارتونی", "انیمه", "نقاشی", "ویرایش", "تغییر", "بشه", "کن", "style"]):
        await update.message.reply_text("🎨 دارم پرامپت می‌سازم...")
        prompt = image_to_prompt(image_base64, caption)
        if prompt:
            await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="upload_photo")
            img_data, eng_prompt = generate_image_pollinations(prompt)
            if img_data:
                await update.message.reply_photo(photo=img_data, caption="🎨 عکس ویرایش شد!")
            else:
                await update.message.reply_text("⚠️ ساخت عکس ناموفق بود.")
        else:
            await update.message.reply_text("⚠️ خطا در پردازش.")

    elif caption:
        reply = analyze_image(image_base64, caption)
        await update.message.reply_text(reply or "⚠️ خطا در تحلیل عکس.")

    else:
        reply = analyze_image(image_base64, "این عکس رو به فارسی توضیح بده.")
        await update.message.reply_text(reply or "⚠️ خطا در تحلیل عکس.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_info = get_user(user.id, user)
    increment_messages(user.id)
    text = update.message.text.strip()
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")

    # ساخت عکس
    if text.startswith("عکس ") or text.startswith("image "):
        prompt = text.split(" ", 1)[1]
        await update.message.reply_text("🎨 دارم عکس می‌سازم...")
        await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="upload_photo")
        img_data, _ = generate_image_pollinations(prompt)
        if img_data:
            await update.message.reply_photo(photo=img_data, caption="🎨 عکس آماده شد!")
        else:
            await update.message.reply_text("⚠️ ساخت عکس ناموفق بود.")
        return

    # ترجمه
    if text.startswith("ترجمه ") or text.startswith("translate "):
        content = text.split(" ", 1)[1]
        msgs = [{"role": "user", "content": f"این متن رو ترجمه کن. اگه فارسیه به انگلیسی، اگه انگلیسیه به فارسی ترجمه کن:\n\n{content}"}]
        reply = call_openrouter(msgs)
        await update.message.reply_text(reply or "⚠️ ترجمه ناموفق بود.")
        return

    # خلاصه‌سازی
    if text.startswith("خلاصه ") or text.startswith("summary "):
        content = text.split(" ", 1)[1]
        msgs = [{"role": "user", "content": f"این متن رو به فارسی خلاصه کن:\n\n{content}"}]
        reply = call_openrouter(msgs)
        await update.message.reply_text(reply or "⚠️ خلاصه‌سازی ناموفق بود.")
        return

    # جستجو
    if text.startswith("جستجو ") or text.startswith("search "):
        query = text.split(" ", 1)[1]
        msgs = [{"role": "user", "content": f"در مورد '{query}' اطلاعات کامل بده."}]
        reply = call_openrouter(msgs)
        await update.message.reply_text(reply or "⚠️ جستجو ناموفق بود.")
        return

    reply = ask_ai(user.id, text, user_info)
    await update.message.reply_text(reply)

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("new", new_chat))
    app.add_handler(CommandHandler("profile", profile_command))
    app.add_handler(CommandHandler("setname", setname_command))
    app.add_handler(CommandHandler("setinterest", setinterest_command))
    app.add_handler(CommandHandler("personality", personality_command))
    app.add_handler(CommandHandler("roleplay", roleplay_command))
    app.add_handler(CommandHandler("remind", remind_command))
    app.add_handler(CommandHandler("stats", stats_command))
    app.add_handler(CommandHandler("broadcast", broadcast_command))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    logger.info("✅ ParsMind Bot v4 روشن شد!")
    app.run_polling()

if __name__ == "__main__":
    main()
